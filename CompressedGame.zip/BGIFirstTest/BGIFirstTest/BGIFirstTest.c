// BGIFirstTest.c : Example graphic application
//


#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>

void main(void)
{
	// Initialise graphic window
	int gd = DETECT, gm = 0;
	initgraph(&gd, &gm, "");
	printf("Hello, world\n");

	// example of use of graphic primitives
	circle(400, 100, 40);
	line(400, 100, 428, 82);

	// wait for key pressed
	readkey();

	// close graphic
	closegraph();
}